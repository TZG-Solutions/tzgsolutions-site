TZ.G Solutions Email Signature v2.6.2 - Crisp

Based directly on v2.6.1 Spark Compact.

Changes in v2.6.2 only:
- Restored the two gold horizontal separators using fixed-size PNG line assets for safer email rendering.
- Added new high-resolution phone, email, website and vCard icons.
- Increased displayed phone/email/web icon size to 24x24 px while keeping compact spacing.
- Increased contact text to 14 px for better readability.
- Made both each contact icon and its text clickable.
- QR, hosted vCard, contact photo, left logo, divider and overall compact layout are preserved.

GitHub upload:
Upload/merge the contents of email-signature/ into /email-signature/ at the site root.
The contact/ folder is unchanged from v2.6.1 and should remain available at /contact/.

Spark:
After the new icon/line assets are live, open signature-setup/signature-hosted.html and paste it as a NEW signature in Spark.
